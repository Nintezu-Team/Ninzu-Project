// SPDX-FileCopyrightText: Copyright 2023 yuzu Emulator Project
// SPDX-License-Identifier: GPL-2.0-or-later

#pragma once

#include <stb_image.h>
#include <stb_image_resize.h>
#include <stb_image_write.h>
