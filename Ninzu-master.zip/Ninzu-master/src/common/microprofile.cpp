// SPDX-FileCopyrightText: 2015 Citra Emulator Project
// SPDX-License-Identifier: GPL-2.0-or-later

// Includes the MicroProfile implementation in this file for compilation
#define MICROPROFILE_IMPL 1
#include "common/microprofile.h"
